<?php
session_start();
if (!isset($_SESSION['login'])) {
    header ("location:login.php?pesan=login");
}
include "koneksi.php";

$no = $_GET['no'];
$sql = "SELECT * FROM post WHERE no = '$no' ";
$query = mysqli_query($koneksi, $sql);
while ($post = mysqli_fetch_assoc($query)) {
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instagram</title>
    <link rel="stylesheet" href="stylee.css">
    <link rel="icon" type="image/x-icon" href="drama.png" width="30%">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Audiowide">
</head>
<body>
  
<nav class="navbar navbar-expand-lg bg-body-tertiary sticky-top">
    <div class="container-fluid">
    <img src="drama.png" width="50px" alt="">
    <a class="navbar-brand" href="index.php" style="font-family:Audiowide, sans-serif">PICT DRAMA</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
      </ul>
      <span class="navbar-text">
      <a href="tambah.php"><button class="btn btn-sm btn-primary" type="button" title = "Tambah data"><i class="fas fa-user-plus"></i></button></a>
      <a href="logout.php"><button class="btn btn-sm btn-secondary" type="button" title = "Keluar"><i class="fas fa-power-off"></i>Keluar</button></a>
      </span>
     
    </div>
  </div>
</nav>
    <div class="card col-sm-6 mx-auto mt-5">
    <h5 class="card-header">Form Edit</h5>
    <div class="card-body">
    <form action="proses_edit.php" method="post" enctype="multipart/form-data" autocomplete = "off">
        <input type="hidden" name="no" value="<?= $post['no'] ?>">
        <input type="hidden" name="gambarlama" value="<?= $post['gambar'] ?>">

        <div class="form-group">
        <label for="">Judul</label>
        <input type="text"  class = "form-control" name="judul" id="" value="<?= $post['judul'] ?>">
        </div><br>

        <div class="form-group">
        <label for="">Caption</label>
        <input type="text"  class = "form-control" name="caption" id="" value="<?= $post['caption'] ?>">
        </div><br>
        <div class="form-group">
        <label for="">Genre</label>
        <input type="text" name="kategori"  class = "form-control" id="" value="<?= $post['kategori'] ?>" required>
        </div><br>
        <div class="form-group">
        <label for="">Gambar</label>
        <input type="file" class = "form-control" name="gambar" value="<?= $post['gambar'] ?>"><br>
        <img src="images/<?= $post['gambar'] ?>" width="200" alt="" ><br>
        </div><br>
        <button type="submit" class = "btn btn-primary" name = "update">POST</button>
    </form>
    </div>
</body>
</html>

<?php } ?>

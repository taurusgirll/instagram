<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>Login</title>
    <link rel="stylesheet" href="style2.css">
  </head>
  <body>
    <form action="proses_login.php" class="form" method = "POST" autocomplete = "off">
      <span></span>
      <span></span>
      <span></span>
      <span></span>
      <div class="form-inner">
        <h2>LOGIN</h2>
        <div class="content">
          <input class="input" name = "username" type="text" placeholder="Username" />
          <input class="input"  name = "password" type="password" placeholder="Password" />
          <button class="btn">Login</button>
      </div>


    </form>
  </body>
</html>

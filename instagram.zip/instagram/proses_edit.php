<?php
session_start();
if (!isset($_SESSION['login'])) {
    header ("location:login.php?pesan=login");
}
include "koneksi.php";
require "functions.php";

if (isset($_POST['update'])) {
    $no = $_POST['no'];
    $judul = $_POST['judul'];
    $caption = $_POST['caption'];
    $kategori = $_POST['kategori'];
    $gambarlama = $_POST['gambarlama'];
    $foto_baru = $_FILES['gambar']['name'];

    // jika gambarnya sama, pakai gambar yang lama
    if( $_FILES['gambar']['error'] === 4 ) {
		$gambar = $gambarlama;
	} else {
        $sql = "SELECT * FROM post WHERE no = '$no' ";
        $query = mysqli_query($koneksi, $sql);
    
        // menghapus gambar lama karena nanti akan diganti yang baru
        while($post = mysqli_fetch_assoc($query)) {
            $gambar = $post['gambar'];
            unlink('images/' . $gambar);
        }

        // lakukan proses upload gambar baru
		$gambar = upload();
	}
    
    $sql2 = "UPDATE post SET judul ='$judul',caption = '$caption', kategori = '$kategori', gambar = '$gambar' WHERE no = '$no' ";
    $query2 = mysqli_query($koneksi, $sql2);

    echo "<script> 
            alert('Data berhasil diubah!');
            document.location.href = 'index.php';
        </script>
    ";
    
}
?>
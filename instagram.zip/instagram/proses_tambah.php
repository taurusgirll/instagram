<?php
session_start();
if (!isset($_SESSION['login'])) {
    header ("location:login.php?pesan=login");
}
include "koneksi.php";
require "functions.php";

if (isset($_POST['simpan'])) { //memastikan tombol simpan di klik mengambil dari name = "simpan"
    $gambar = upload();
    $judul = $_POST['judul'];
    $caption = $_POST['caption'];
    $kategori = $_POST['kategori'];

    $sql = "INSERT INTO post (gambar,judul,caption,kategori) VALUES ('$gambar','$judul','$caption','$kategori')";
    $query = mysqli_query($koneksi,$sql);
    
    echo "<script> 
            alert('Data berhasil ditambah!');
            document.location.href = 'index.php';
        </script>
    ";
        
}
?>
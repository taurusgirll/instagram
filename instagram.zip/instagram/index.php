<?php
session_start();
if (!isset($_SESSION['login'])) {
    header ("location:login.php?pesan=login");
}
include "koneksi.php";
$sql = "SELECT*FROM post ORDER BY no DESC";
$query = mysqli_query($koneksi,$sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trailer Dracin</title>
    <link rel="stylesheet" href="stylee.css">
    <link rel="icon" type="image/x-icon" href="drama.png" width="30%">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Audiowide">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10.15.7/dist/sweetalert2.all.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
</head>
<body>
<nav class="navbar navbar-expand-lg bg-body-tertiary sticky-top">
    <div class="container-fluid">
    <img src="drama.png" width="50px" alt="">
    <a class="navbar-brand" href="index.php" style="font-family:Audiowide, sans-serif">DramaKita</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
      </ul>
      <span class="navbar-text">
     <button  class="btn btn-sm btn-primary"><i class="fas fa-user-plus" data-bs-toggle="modal" data-bs-target="#tambah"></i></button>
      <a href="logout.php"><button class="btn btn-sm btn-secondary" type="button" title = "Keluar"><i class="fas fa-power-off"></i>Keluar</button></a>
      </span>
     
    </div>
  </div>
</nav><br><br>

<div class = "container">
<?php while ($post=mysqli_fetch_assoc($query)) { ?>
<center>
<div class="card mb-3 col-sm-8 ">
  <img src="images/<?=$post['gambar']?>" alt="" width= "100" id = "card" class="card-img-top">
  <div class="card-body">   
   <h5 class="card-title"><?=$post['judul']?></h5>
    <h6 class="card-subtitle mb-2 text-body-secondary"><?=$post['kategori']?></h6>
    <p class="card-text"><?=$post['caption']?></p>
    <hr>
    <button  class="btn btn-sm btn-success"><i class="fas fa-edit" data-bs-toggle="modal" data-bs-target="#edit<?= $post['no']?>"></i></button> |
    <a  onclick="confirmDelete(<?php echo $post['no'] ?>)"><button class="btn btn-sm btn-danger" title = "Hapus data" type="button"><i class="fas fa-trash"></i></button></a>
      
  </div>
</div>

</center>
<div class="modal fade" data-bs-backdrop="static"  id="edit<?=$post['no']?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Form Edit</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form action="proses_edit.php" method="post" enctype="multipart/form-data" autocomplete="off">
      <input type="hidden" name="no" value="<?= $post['no'] ?>">
      <input type="hidden" name="gambarlama" value="<?= $post['gambar'] ?>">
                <div class="form-group">
                <label for="">Judul</label>
                <input type="text" class = "form-control" name="judul" placeholder="Masukkan data"  value="<?=$post['judul']?>"><br>
                </div>
                  <div class="form-group">
                    <label for="">Caption</label>
                    <textarea type="text" class="form-control" name="caption" id=""><?=$post['caption']?></textarea>
                </div><br>
                <div class="form-group">
                    <label for="">Genre</label>
                    <input type="text" name="kategori" class="form-control" id="" value="<?= $post['kategori'] ?>" required>
                </div><br>
                <div class="form-group">
                    <label for="">Gambar</label>
                    <input type="file" class = "form-control" name="gambar" value="<?=$post['gambar'] ?>"><br>
                    <img src="images/<?= $post['gambar'] ?>" width="200" alt=""><br>
                </div><br>
             
      </div>
      <div class="modal-footer">
      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      <button type="submit" class= "btn btn-primary" name="update">Update</button>
            </form>
      </div>
    </div>
  </div>
</div>
    <?php } ?>
    </div><br><br>
    
<!-- Modal -->
<div class="modal fade" id="tambah" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="staticBackdropLabel">Form Tambah</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form action="proses_tambah.php" method="post" enctype="multipart/form-data" autocomplete = "off">
        <div class="form-group">
        <label for="">Gambar</label>
        <input type="file" class = "form-control" name="gambar" placeholder="Masukkan data" required><br>
        </div>
        <div class="form-group">
        <label for="">Judul</label>
        <input type="text" class = "form-control" name="judul" placeholder="Masukkan data" required><br>
        </div>
        <div class="form-group">
        <label for="">Caption</label>
        <textarea type="text" name="caption"  class = "form-control" placeholder="Masukkan data" required></textarea><br>
        </div>
        <div class="form-group">
        <label for="">Genre</label>
        <input type="text" name="kategori"  class = "form-control" placeholder="Masukkan data" required><br>
        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary" name="simpan">Post</button>     
</form>
</div>
    </div>
  </div>
</div>
<script>
    function confirmDelete(postId) {
        Swal.fire({
            title: 'Hapus data ini?',
            text: "jika anda menghapusnya, anda tidak akan dapat mengembalikan data ini lagi",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            ConfirmButtonText: 'Ya',
            cancelButtonColor: '#3085d6',
            cancelButtonText: 'Batal'
        }).then(result => {
            if(result.isConfirmed) {
                window.location.href = 'hapus.php?no=' + postId;
            }
        });
    }
</script>

</body>
</html>